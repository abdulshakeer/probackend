const express = require('express')
const format = require("date-format")
const app = express()
const port = process.env.port || 4000 ;

app.get('/', (req, res) => {
  res.status(201).send('<h1>Hello World!</h1>')
})


app.get('/api/v1/instagram',(req,res)=>{
    const instagram = {
        username: " Abdul Shakir",
        followers : 100,
        follows:60,
        date:format.asString("dd[MM] - hh:mm:ss",new Date()),
    };
    res.status(200).json(instagram)
})

app.get('/api/v1/facebook',(req,res)=>{
    const instagram = {
        username: " Abdul Shakir",
        followers : 300,
        follows:100,
        date:format.asString("dd[MM] - hh:mm:ss",new Date()),
    };
    res.status(200).json(instagram)
})

app.get('/api/v1/linkedin',(req,res)=>{
    const instagram = {
        username: " Abdul Shakir",
        followers : 1500,
        follows:200,
        date:format.asString("dd[MM] - hh:mm:ss",new Date()),

    };
    res.status(200).json(instagram)
})

app.get('/api/v1/:token',(req,res)=>{
    console.log(req.params.token);
    res.status(200).json({params:req.params.token})
})





app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})